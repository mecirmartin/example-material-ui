const en = {
    "customers": "CUSTOMERS",
    "total.customers": "TOTAL CUSTOMERS",
    "total.profit": "TOTAL PROFIT",
    "budget": "BUDGET",
    "tasks.progress": "TASKS PROGRESS"
}

export default en