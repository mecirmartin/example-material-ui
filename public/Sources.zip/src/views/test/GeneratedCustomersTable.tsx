import React from 'react'
import { useIntl,FormattedMessage } from "react-intl";
import { GridColParams,DataGrid } from "@material-ui/data-grid";
export default function CustomerTable({ customers }) {
const intl = useIntl();
const columns = [
{ field: "id", flex: 1, type: "string", valueFormatter: ({ value }) => value, renderHeader: (params: GridColParams) => () },
{ field: "name", flex: 1, type: "string", valueFormatter: ({ value }) => value, renderHeader: (params: GridColParams) => () },
{ field: "createdAt", flex: 1, type: "date", valueFormatter: ({ value }) => intl.formatDate(value), renderHeader: (params: GridColParams) => () },
{ field: "email", flex: 1, type: "string", valueFormatter: ({ value }) => value, renderHeader: (params: GridColParams) => () },
];
return (<div style={{ height: "400px", width: "100%" }}>);
}