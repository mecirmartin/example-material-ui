export interface Customer {
    avatarUrl: string;
    createdAt: number;
    email: string;
    name: string;
    phone: string;
    updatedAt: number;
    test2: number;
  }