import data from "../customer/CustomerListView/data"
import React, { useState } from "react"
import GeneratedTable from "./GeneratedCustomersTable"

const CustomerListView = () => {
  return <GeneratedTable customers={data} />
}
export default CustomerListView
