import React from 'react';

const HelloWorld = () => {
  return (
    <div>
      <h1>Hello world</h1>
    </div>
  );
};

export default HelloWorld;
