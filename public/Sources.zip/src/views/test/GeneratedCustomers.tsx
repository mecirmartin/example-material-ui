import GeneratedTable from './GeneratedCustomersTable'
import data from './data';

const CustomerListView = () => {

  return (
    <GeneratedTable customers={data} />
  );
};
export default CustomerListView
