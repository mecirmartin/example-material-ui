const sk = {
    "customers": "ZÁKAZNÍCI",
    "total.customers": "ZÁKAZNÍCI CELKOVO",
    "total.profit": "ZISK CELKOVO",
    "budget": "ROZPOČET",
    "tasks.progress": "STAV ÚLOH"
}

export default sk